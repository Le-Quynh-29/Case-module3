<?php

return [
    'Trang chủ' => 'Home page',
    'Danh sách khách hàng' => 'List of customers',
    'Danh sách sản phẩm' => 'List of products',
    'Dòng sản phẩm' => 'Product line',
    'Danh sách' => 'Lists',
    'Đặt hàng' => 'Orders',
    'Chi tiết đặt hàng' => 'Orderdetail'

];
