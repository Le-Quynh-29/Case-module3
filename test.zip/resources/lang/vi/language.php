<?php

return [
    'Trang chủ'=> 'Trang chủ',
    'Danh sách khách hàng' => 'Danh sách khách hàng',
    'Danh sách sản phẩm' => 'Danh sách sản phẩm',
    'Dòng sản phẩm' => 'Dòng sản phẩm',
    'Danh sách'=>' Danh sách',
    'Đặt hàng' => 'Danh sách hóa đơn',
    'Chi tiết đặt hàng'=> 'Danh sách chi tiết hoá đơn'

];

