<?php $__env->startSection('title'); ?>
    Thêm mới sản phẩm
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <style>
        h1{
            font-size: 70px!important;

        }
        td{
            font-size: 20px!important;
            color: black!important;

        }
        th{
            font-size:25px!important;
            color: black!important;

        }
        label{
            font-size: 25px!important;
        }
        input{
            font-size: 20px!important;
        }
        button{
            font-size: 20px!important;
        }
    </style>
    <div class="col-12 col-md-12">
        <div class="row">
            <div class="col-12">
                <h1>Thêm mới sản phẩm </h1>
            </div>
            <div class="col-12">
                <form method="post" action="<?php echo e(route('products.store')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label>Tên sản phẩm </label>
                        <input type="text" class="form-control" name="productName"  placeholder="Enter name">
                    </div>
                    <div class="form-group">
                        <label>Dòng sản phẩm </label>
                        <select class="form-control" name="productLine">
                            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value->id); ?>"><?php echo e($value->id); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Số lượng </label>
                        <input type="number" class="form-control" name="quantity" placeholder="Enter quantity">
                    </div>
                    <div class="form-group">
                        <label>Giá</label>
                        <input type="text" class="form-control" name="price" placeholder="Enter price">
                    </div>

                    <div class="form-group">
                        <label>Phần trăm giảm giá</label>
                        <input type="text" class="form-control" name="voucher" placeholder="Enter voucher">
                    </div>
                    <div class="form-group">
                        <label for="inputName">Tên ảnh </label>
                        <input type="text"
                               id="inputName"
                               name="inputName" class="form-control">
                        <input type="file"
                               id="inputFile"
                               name="inputFile" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Mô tả</label>
                        <textarea name="descripton" class="form-control" style="height: 200px" placeholder="Enter descripton"></textarea>
                        
                    </div>
                    <button type="submit" class="btn btn-primary">Thêm mới</button>
                    <button class="btn btn-secondary" onclick="window.history.go(-1); return false;">Hủy</button>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Case-module3/resources/views/backend/products/create.blade.php ENDPATH**/ ?>