<?php $__env->startSection('frontend-master'); ?>


<?php echo $__env->yieldContent('productline'); ?>


    <?php $__env->stopSection(); ?>



<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Case-module3/resources/views/frontend/show.blade.php ENDPATH**/ ?>