<?php $__env->startSection('frontend-master'); ?>

    <div class="about-box-main">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="banner-frame">
                        <img class="img-fluid" src="<?php echo e(asset('storage/images/' . $productlines->img)); ?>" alt="" style="height: 500px"/>
                    </div>
                </div>
                <div class="col-lg-6">
                    <h2 class="noo-sh-title-top"> <span><?php echo e($productlines->id); ?></span></h2>
                    <p style="color: black;font-size: 20px">
                        <?php echo e($productlines->description); ?>

                    </p>
                    <button class="btn btn-secondary" onclick="window.history.go(-1); return false;">Cancle</button>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Case-module3/resources/views/frontend/showproductline.blade.php ENDPATH**/ ?>