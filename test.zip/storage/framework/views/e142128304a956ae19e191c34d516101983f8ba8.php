<?php $__env->startSection('title'); ?>
    Chi tiết đơn hàng
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <style>
        h1{
            font-size: 70px!important;

        }
        td{
            font-size: 20px!important;
        }
        th{
            font-size:25px!important;

        }
        button{
            font-size: 15px!important;
        }
    </style>
    <div class="col-12">
        <div class="row">
            <div class="col-12">
                <h1>Chi tiết đơn hàng </h1>
            </div>
            <a style="font-size: 25px!important;" class="btn btn-primary" href="<?php echo e(route('orderdetails.create')); ?>">Thêm mới</a>
            <table class="table table-striped">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Mã đơn hàng</th>
                    <th scope="col">Tên sản phẩm</th>
                    <th scope="col">Số lượng  </th>
                    <th scope="col">Giá tiền </th>

                    <th></th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $orderdetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $orderdetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e(++$key); ?></th>
                        <td><?php echo e($orderdetail->orderNumber); ?></td>
                        <td><?php echo e($orderdetail->Product()->first()->productName); ?></td>
                        <td><?php echo e($orderdetail->quantity); ?></td>
                        <td><?php echo e($orderdetail->price); ?></td>

                        <td><a href="<?php echo e(route('orderdetails.edit', $orderdetail->id)); ?>" class="btn btn-info">Sửa</a></td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div style="font-size:25px;text-align: right!important; ">
                <?php echo e($orderdetails->links()); ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Case-module3/resources/views/backend/orderdetails/list.blade.php ENDPATH**/ ?>