<?php $__env->startSection('title'); ?>
    Chỉnh sửa dòng sản phẩm
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <style>
        h1{
            font-size: 70px!important;

        }
        td{
            font-size: 20px!important;
            color: black!important;

        }
        th{
            font-size:25px!important;
            color: black!important;

        }
        label{
            font-size: 25px!important;
        }
        input{
            font-size: 20px!important;
        }
        button{
            font-size: 20px!important;
        }
    </style>
    <div class="col-12 col-md-12">
        <div class="row">
            <div class="col-12">
                <h1>Chỉnh sửa dòng sản phẩm </h1>
            </div>
            <div class="col-12">
                <form method="post" action="<?php echo e(route('productline.update', $productline->id)); ?>"  enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label>Dòng sản phẩm </label>
                        <input type="text" class="form-control" name="id" value="<?php echo e($productline->id); ?>">
                    </div>

                    <div>
                        <label for="inputName">Tên ảnh </label>
                        <input type="text"
                               id="inputName"
                               name="inputName">
                        <input type="file"
                               id="inputFile"
                               name="inputFile">
                    </div>
                    <div class="form-group">
                        <label>Mô tả</label>
                        <textarea style="height: 200px" class="form-control" name="description" ><?php echo e($productline->description); ?></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary">Chỉnh sửa</button>
                    <button class="btn btn-secondary" onclick="window.history.go(-1); return false;">Hủy</button>
                </form>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Case-module3/resources/views/backend/productline/edit.blade.php ENDPATH**/ ?>