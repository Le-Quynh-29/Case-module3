<?php $__env->startSection('title'); ?>
    Danh sách khách hàng
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <style>
        h1{
            font-size: 70px!important;

        }
        td{
            font-size: 20px!important;
            color: black!important;
            text-align: center!important;


        }
        th{
            font-size:25px!important;
            color: black!important;
            text-align: center!important;

        }
        button{
            font-size: 15px!important;
        }
        /*a{*/
        /*    font-size: 30px!important;*/
        /*}*/
    </style>
    <div class="col-12">
        <div class="row">
            <div class="col-12">
                <h1>Danh Sách Khách Hàng</h1>
            </div>
            <a style="font-size: 25px!important;" class="btn btn-primary" href="<?php echo e(route('customers.create')); ?>">Thêm mới</a>
            <table class="table table-striped">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Tên khách hàng</th>
                    <th scope="col">Địa chỉ</th>
                    <th scope="col">Email</th>
                    <th scope="col">Số điên thoại</th>
                    <th></th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($key + $customers-> firstItem()); ?></th>
                        <td><?php echo e($customer->user); ?></td>
                        <td><?php echo e($customer->address); ?></td>
                        <td><?php echo e($customer->email); ?></td>
                        <td><?php echo e($customer->phone); ?></td>
                        <td><a href="<?php echo e(route('customers.edit', $customer->id)); ?>" class="btn btn-info">Sửa</a></td>
                        <td><a href="<?php echo e(route('customers.destroy', $customer->id)); ?>" class="btn btn-danger" onclick="return confirm('Bạn chắc chắn muốn xóa?')">Xóa</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

                <div style="float: right;"><?php echo e($customers->links( "pagination::bootstrap-4")); ?></div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Case-module3/resources/views/backend/customers/list.blade.php ENDPATH**/ ?>