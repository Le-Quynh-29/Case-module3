<?php $__env->startSection('title'); ?>
    Danh sách sản phẩm
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <style>
        h1 {
            font-size: 70px !important;

        }

        td {
            font-size: 20px !important;
            color: black !important;

        }

        th {
            font-size: 25px !important;
            color: black !important;
            text-align: center !important;


        }

        button {
            font-size: 15px !important;
        }

        #text {
            display: -webkit-box;
            width: 300px;
            line-height: 25px;
            overflow: hidden;
            text-overflow: ellipsis;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;

        }
    </style>
    <div class="col-12">
        <div class="row">
            <div class="col-12">
                <h1>Danh Sách Sản Phẩm</h1>
            </div>
            <a style="font-size: 25px!important;" class="btn btn-primary" href="<?php echo e(route('products.create')); ?>">Thêm
                mới</a>
            <table class="table table-striped">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Tên sản phẩm</th>
                    <th scope="col">Dòng sản phẩm</th>
                    <th scope="col">Mô tả</th>
                    <th scope="col">Số lượng</th>
                    <th scope="col">Giá</th>

                    <th scope="col">Mã giảm giá</th>
                    <th scope="col">Hình ảnh</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>

                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($key + $products ->firstItem()); ?></th>
                        <td><?php echo e($product->productName); ?></td>
                        <td><?php echo e($product->productLine); ?></td>
                        <td> <?php echo substr($product->descripton, 0, 100); ?>  ...</td>
                        <td><?php echo e($product->quantity); ?></td>
                        <td><?php echo e(number_format($product->price)); ?></td>

                        <td><?php echo e($product->voucher); ?></td>

                        <td>
                            <img src="<?php echo e(asset ('storage/images/'.$product->img)); ?> " alt=""
                                 style="width: 100px ;height: 100px">
                        </td>
                        <td>
                            <a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-info">Sửa</a>
                            <a href="<?php echo e(route('products.delete', $product->id)); ?>" class="btn btn-danger"
                               onclick="return confirm('Bạn chắc chắn muốn xóa?')">Xóa</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <div style="float: right;"><?php echo e($products->links( "pagination::bootstrap-4")); ?></div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Case-module3/resources/views/backend/products/list.blade.php ENDPATH**/ ?>