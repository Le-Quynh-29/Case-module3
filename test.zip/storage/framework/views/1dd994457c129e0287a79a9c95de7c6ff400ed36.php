<?php $__env->startSection('title'); ?>
    Thêm mới dòng sản phẩm
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <style>
        h1{
            font-size: 70px!important;

        }
        td{
            font-size: 20px!important;
            color: black!important;

        }
        th{
            font-size:25px!important;
            color: black!important;

        }
        label{
            font-size: 25px!important;
        }
        input{
            font-size: 20px!important;
        }
        button{
            font-size: 20px!important;
        }
    </style>
    <div class="sub-main-w3">
        <h1>Thêm dòng sản phẩm</h1>
        <form method="post" action="<?php echo e(route('productline.store')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label>Dòng Sản Phẩm</label>
                <input type="text" name="id" class="form-control">
            </div>


            <div class="form-group">
                <label for="inputName">Tên ảnh </label>
                <input type="text"
                       id="inputName"
                       name="inputName" class="form-control">
                <input type="file"
                       id="inputFile"
                       name="inputFile" class="form-control">
            </div>
            <div class="form-group">
                <label>Mô Tả</label>
                <textarea style="height: 200px" name="description" class="form-control"></textarea>
            </div>
            <button type="submit" value="add" class="btn btn-primary">ADD</button>
            <button onclick="window.history.go(-1); return false;">Cancle</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Case-module3/resources/views/backend/productline/create.blade.php ENDPATH**/ ?>