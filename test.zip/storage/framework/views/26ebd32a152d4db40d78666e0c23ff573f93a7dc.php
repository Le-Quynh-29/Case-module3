<?php $__env->startSection('title'); ?>
    Danh sách hóa đơn
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <style>
        h1{
            font-size: 70px!important;

        }
        td{
            font-size: 20px!important;
        }
        th{
            font-size:25px!important;

        }
        button{
            font-size: 15px!important;
        }
        /*a{*/
        /*    font-size: 30px!important;*/
        /*}*/
    </style>
    <div class="col-12">
        <div class="row">
            <div class="col-12">
                <h1>Danh sách hóa đơn</h1>
            </div>
            <a style="font-size: 25px!important;" class="btn btn-primary" href="<?php echo e(route('orders.create')); ?>">Thêm mới</a>
            <table class="table table-striped">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Tên khách hàng</th>

                    <th scope="col">Ngày đặt hàng </th>
                    <th scope="col">Yêu cầu đặt hàng </th>
                    <th scope="col">Ngày vận chuyển</th>
                    <th scope="col">Trạng thái</th>
                    <th></th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e(++$key); ?></th>
                        <td><?php echo e($order->customer()->first()->user); ?></td>
                        <td><?php echo e($order->orderDate); ?></td>
                        <td><?php echo e($order->requiredDate); ?></td>
                        <td><?php echo e($order->shippedDate); ?></td>
                        <td><?php echo e($order->status); ?></td>
                        <td><a href="<?php echo e(route('orders.edit', $order->id)); ?>" class="btn btn-info">Sửa</a></td>
                        <td><a href="<?php echo e(route('orders.destroy', $order->id)); ?>" class="btn btn-danger" onclick="return confirm('Bạn chắc chắn muốn xóa?')">Xóa</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div style="font-size:25px;text-align: right!important; ">
                <?php echo e($orders->links()); ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Case-module3/resources/views/backend/orders/list.blade.php ENDPATH**/ ?>